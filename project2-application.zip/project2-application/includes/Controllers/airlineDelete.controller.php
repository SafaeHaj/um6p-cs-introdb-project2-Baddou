<?php
require_once '../database.inc.php';
require_once '../Models/airline.model.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $operationType = $_POST['fid'];
    cancelFlight($operationType);
    exit();
}

?>