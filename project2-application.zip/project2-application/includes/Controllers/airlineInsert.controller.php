<?php
require_once '../database.inc.php';
require_once '../Models/airline.model.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $destination = $_POST["destination"];
    $departure = $_POST["departure"];
    $departureTime = $_POST["departureTime"];
    $arrivalTime = $_POST["arrivalTime"];
    $registrationNumber = $_POST["airplane"];
    $price = $_POST["price"];

    insertFlight($departure, $destination, $departureTime, $arrivalTime, $registrationNumber, $price);
    
    header("Location ../Views/airline.view.php");
    exit(); 

}

?>