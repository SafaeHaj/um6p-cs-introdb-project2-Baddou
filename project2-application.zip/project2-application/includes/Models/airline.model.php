<?php

function cancelFlight($fid){
    $sql = "CALL CancelFlight('$fid')";
    executeQuery($sql);
}

function generatefid() {
    $prefix = 'FF';
    $uniqueId = uniqid();
    $ticketId = $prefix . $uniqueId;
    return $ticketId;
}

function insertFlight($departure, $destination, $departureTime, $arrivalTime, $registrationNumber, $price) {
    $fid = generatefid();
    $sql = "INSERT INTO Flight (fid, departure, destination, departureTime, arrivalTime, registrationNumber, price) 
            VALUES ('$fid', '$departure', '$destination', '$departureTime', '$arrivalTime', '$registrationNumber', '$price')";
    executeQuery($sql);
}

function getFlightsByAirline($airline){
    $sql = "SELECT * FROM flight F 
            JOIN airplane A ON F.registrationNumber = A.registrationNumber 
            WHERE A.airline = '$airline' AND status_ != 'Cancelled' 
            ORDER BY departureTime DESC;";
    
    $result = executeQuery($sql);
    return $result -> fetch_all(MYSQLI_ASSOC);
}

?>