<?php
session_start();

require_once '../database.inc.php';
require_once '../Models/airline.model.php';

$airline = isset($_SESSION["user_email"]) ? $_SESSION["user_email"] : null;
$flights = getFlightsByAirline($airline);

function generateFlightHTML($flight) {
    return '
    <div class="flight-container">
        <div class="flight">
            <p class="fid">' . $flight['fid'] . '</p>
            <p class="departure">' . $flight['departure'] . '</p>
            <p class="destination">' . $flight['destination'] . '</p>
            <p class="departureTime">' . $flight['departureTime'] . '</p>
            <p class="arrivalTime">' . $flight['arrivalTime'] . '</p>
            <p class="airplane">' . $flight['model'] . '</p>
            <p class="price">' . $flight['price'] . '</p>
        </div>
        <button class="delete" onclick=\'sendPostRequest("' . $flight['fid'] . '")\'>x</button>
    </div>';
}
?>

<!DOCTYPE html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../css/airlines.css">
    <title>Airnest: Airlines</title>
</head>

<body>
<header>
        <div class="title-logo">
            <img src="../../assets/img/airnest_logo.png">
            <div class="title">
                <h1>Airnest</h1>
                <p>One <span class=f-orange>search</span>, millions of <span class=f-orange>destinations</span></p>
            </div>
        </div>

        <div class="account">
            <button class="register orange" id="logout_btn">Log Out</button>
        </div>
    </header>

    <main>
        <div class="under-head">
            <h2>Your flights</h2>
            <button class="flight-insert" id="insert_btn">Insert Flight</button>
        </div>
        <div class="flights-list">
            <?php
                foreach ($flights as $flight) {
                    echo generateFlightHTML($flight);
                }
            ?>
        </div>

        <div id="formhidden" class="hidden">
            <form class="flight-form" method="post" action="../Controllers/airlineInsert.controller.php">
        
            <div class="search-container">
                <label for="departure">Airport of Departure</label>
                <input name="departure" id="departure"> 
                <div id="departureResults" class="search-results"></div>
            </div>
            <div class="search-container">
                <label for="destination">Airport of Destination</label>
                <input name="destination" id="destination">
                <div id="departureResults" class="search-results"></div>
            </div>
                <label for="departureTime">Departure Time</label>
                <input name="departureTime" type="datetime-local">

                <label for="arrivalTime">Arrival Time</label>
                <input name="arrivalTime" type="datetime-local">

                <label for="airplane">Airplane Registration Number</label>
                <input name="airplane">

                <label for="price">Price</label>
                <input name="price">

                <input name="submit" type="submit" value="Add flight">
                <input name="reset" type="reset" value="Reset">
            </form>
        </div>
        
    </main>

    <script src="../../js/airlineManager.js"></script>
    <script src="../../js/logoutButton.js"></script>
    <script src="../../js/mainIndex.js"></script>

</body>

