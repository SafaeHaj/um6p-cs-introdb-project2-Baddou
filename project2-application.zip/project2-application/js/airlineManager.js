
const insert_btn = document.getElementById('insert_btn');
const formContainer = document.getElementById('formhidden');

insert_btn.addEventListener("click", function(){
    formContainer.classList.toggle('hidden')
})

function sendPostRequest(fid) {
    console.log(fid);
    const url = '../Controllers/airlineDelete.controller.php'; 
    const data = new URLSearchParams();
    data.append('fid', fid); 

    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: data,
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.text();
    })
    .then(data => {
        location.reload();
    })
    .catch(error => {
        console.error('There was a problem with the fetch operation:', error);
    });
}
